Easily compare various DeFi protocols based on their market capitalization and total value locked, using DeFiLlama data.

Data Source: [DefiLlama](https://defillama.com/)
