### Description

This page helps you manage and edit script files to run with Hummingbot instances:

- Selecting files
- Editing and saving files

### Maintainers

This page is maintained by Hummingbot Foundation:

* [cardosfede](https://github.com/cardosfede)
* [fengtality](https://github.com/fengtality)
