from hummingbot.strategy.script_strategy_base import ScriptStrategyBase


class CLOBSerumExample(ScriptStrategyBase):
    pass
