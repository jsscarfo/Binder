MINER_COINS = ["Algorand", "Avalanche", "DAO Maker", "Faith Tribe", "Fear", "Frontier",
                   "Harmony", "Hot Cross", "HUMAN Protocol", "Oddz", "Shera", "Firo",
                   "Vesper Finance", "Youclout", "Nimiq"]
MINER_EXCHANGES = ["Binance", "FTX", "Coinbase Exchange", "Huobi Global", "OKX", "KuCoin",
                   "Kraken", "Bybit (Spot)", "FTX.US", "Crypto.com Exchange", "Binance US",
                   "MEXC Global", "Gate.io", "BitMart", "Bitfinex", "AscendEX (BitMax)",
                   "Bittrex", "CoinFLEX", "Digifinex", "HitBTC", "Kraken", "Liquid", ]

DEFAULT_MINER_COINS = ["Avalanche"]

CERTIFIED_EXCHANGES = ["ascendex", "binance", "bybit", "gate.io", "hitbtc", "huobi", "kucoin", "okx", "gateway"]
CERTIFIED_STRATEGIES = ["xemm", "cross exchange market making", "pmm", "pure market making"]